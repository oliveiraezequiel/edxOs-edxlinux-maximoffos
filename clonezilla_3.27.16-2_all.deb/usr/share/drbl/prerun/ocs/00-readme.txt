# The scripts in this direcoty will be run by run-parts comamnd BEFORE ocs-sr starts. 
# //NOTE//:
# You need to enable the option "-o1" otherwise it won't work.
