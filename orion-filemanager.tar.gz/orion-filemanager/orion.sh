#!/bin/bash

USERMODE="user"

if [ "$EUID" -eq 0 ]; then
    USERMODE="root"
fi

APPNAME="Orion File Manager"

CURRENT_DIR="$HOME"

open_terminal() {
    gnome-terminal --working-directory="$CURRENT_DIR"
}

open_root() {
    pkexec bash -c "orion.sh"
}

open_folder() {
    CURRENT_DIR=$(zenity --file-selection --directory --filename="$CURRENT_DIR/")
}

show_files() {

FILES=$(ls "$CURRENT_DIR")

zenity --list \
--title="$APPNAME - $CURRENT_DIR" \
--width=900 \
--height=500 \
--column="Arquivos Orion" $FILES \
--extra-button="Abrir Pasta" \
--extra-button="Terminal Aqui" \
--extra-button="Modo ROOT" \
--ok-label="Abrir" \
--cancel-label="Sair"

}

while true
do

CHOICE=$(show_files)

case "$CHOICE" in

"Abrir Pasta")
open_folder
;;

"Terminal Aqui")
open_terminal
;;

"Modo ROOT")
open_root
;;

"")
exit
;;

*)
xdg-open "$CURRENT_DIR/$CHOICE"
;;

esac

done
