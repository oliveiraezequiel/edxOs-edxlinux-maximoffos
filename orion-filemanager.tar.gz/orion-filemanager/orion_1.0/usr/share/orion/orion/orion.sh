#!/bin/bash

DIR="${1:-$HOME}"

MODE="USER"
COLOR="#0a3b2f"

if [ "$EUID" -eq 0 ]; then
MODE="ROOT"
COLOR="#00aa66"
fi

FILE=$(yad \
--title="Orion File Manager [$MODE]" \
--file \
--width=900 \
--height=600 \
--center \
--add-preview \
--button="Abrir Pasta:1" \
--button="Terminal:2" \
--button="ROOT:3" \
--button="Sair:0")

RET=$?

case $RET in

1)
orion "$FILE"
;;

2)
gnome-terminal --working-directory="$DIR"
;;

3)
pkexec orion
;;

esac
